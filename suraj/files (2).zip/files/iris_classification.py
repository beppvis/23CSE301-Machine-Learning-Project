"""
Passenger Survival Classification
Dataset: titanic_dataset.csv
Model: Random Forest Classifier
"""
from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix
)
import matplotlib.pyplot as plt
import joblib

# Directory for output files (same directory as this script)
OUTPUT_DIR = Path(__file__).resolve().parent

# 1. Load data from the provided CSV dataset
csv_path = OUTPUT_DIR / "titanic_dataset.csv"
raw_df = pd.read_csv(csv_path)

print(f"Loaded dataset: {csv_path.name} (Shape: {raw_df.shape})")

# 2. Data Preprocessing & Feature Engineering
df = raw_df.copy()

# Impute missing Age by Pclass and Sex group medians
df["Age"] = df.groupby(["Pclass", "Sex"])["Age"].transform(lambda x: x.fillna(x.median()))
df["Age"] = df["Age"].fillna(df["Age"].median())

# Impute Fare and Embarked
df["Fare"] = df["Fare"].fillna(df["Fare"].median())
df["Embarked"] = df["Embarked"].fillna(df["Embarked"].mode()[0])

# Feature engineering
df["FamilySize"] = df["SibSp"] + df["Parch"] + 1
df["IsAlone"] = (df["FamilySize"] == 1).astype(int)

# Extract title from passenger Name
df["Title"] = df["Name"].str.extract(r' ([A-Za-z]+)\.', expand=False)
common_titles = ["Mr", "Miss", "Mrs", "Master"]
df["Title"] = df["Title"].apply(lambda t: t if t in common_titles else "Other")

# Encode categorical variables
df["Sex"] = df["Sex"].map({"male": 0, "female": 1})
df = pd.get_dummies(df, columns=["Embarked", "Title"], drop_first=True)

# Define feature columns and target
target_col = "Survived"
target_names = ["Perished", "Survived"]

feature_cols = [
    "Pclass", "Sex", "Age", "SibSp", "Parch", "Fare",
    "FamilySize", "IsAlone",
    "Embarked_Q", "Embarked_S",
    "Title_Miss", "Title_Mr", "Title_Mrs", "Title_Other"
]

X = df[feature_cols].astype(float)
y = df[target_col].astype(int)

# 3. Train/test split (80/20 stratified split)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# 4. Train model
model = RandomForestClassifier(n_estimators=200, max_depth=6, random_state=42)
model.fit(X_train, y_train)

# 5. Evaluate
y_pred = model.predict(X_test)
y_prob = model.predict_proba(X_test)[:, 1]
acc = accuracy_score(y_test, y_pred)
report = classification_report(y_test, y_pred, target_names=target_names)
cm = confusion_matrix(y_test, y_pred)

print(f"Accuracy: {acc:.4f}\n")
print("Classification Report:\n", report)
print("Confusion Matrix:\n", cm)

# 6. Save predictions to CSV
test_indices = X_test.index
results_df = raw_df.loc[test_indices].copy()
results_df["predicted_survived"] = y_pred
results_df["survival_probability"] = np.round(y_prob, 4)
results_df["correct"] = results_df["Survived"] == results_df["predicted_survived"]
results_df.to_csv(OUTPUT_DIR / "titanic_predictions.csv", index=False)

# 7. Save confusion matrix plot
fig, ax = plt.subplots(figsize=(5, 4))
im = ax.imshow(cm, cmap="Blues")
ax.set_xticks(range(len(target_names)))
ax.set_yticks(range(len(target_names)))
ax.set_xticklabels(target_names)
ax.set_yticklabels(target_names)
ax.set_xlabel("Predicted")
ax.set_ylabel("Actual")
ax.set_title(f"Titanic Confusion Matrix (Accuracy: {acc:.2%})")
for i in range(len(target_names)):
    for j in range(len(target_names)):
        ax.text(j, i, cm[i, j], ha="center", va="center",
                color="white" if cm[i, j] > cm.max()/2 else "black")
plt.colorbar(im)
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "confusion_matrix.png", dpi=150)
plt.savefig(OUTPUT_DIR / "titanic_confusion_matrix.png", dpi=150)
plt.close(fig)

# 8. Save the trained model
joblib.dump(model, OUTPUT_DIR / "titanic_model.joblib")

# 9. Save a text report
with open(OUTPUT_DIR / "classification_report.txt", "w") as f:
    f.write("Titanic Survival Classification Report\n")
    f.write("Model: RandomForestClassifier\n")
    f.write(f"Accuracy: {acc:.4f}\n\n")
    f.write(report)
    f.write("\nConfusion Matrix:\n")
    f.write(str(cm))

print("\nAll files and outputs saved successfully.")
