"""
Rice Dataset (Cammeo & Osmancik) - Comprehensive Exploratory Data Analysis (EDA)
Generates high-resolution statistical visualizations, statistical metrics,
feature engineering, PCA, t-SNE, and ML benchmark evaluation.
"""

import os
import sys
import numpy as np
import pandas as pd
import scipy.stats as stats
from scipy.io import arff
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.feature_selection import mutual_info_classif
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score, roc_auc_score

# Set plot style
plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['xtick.labelsize'] = 9
plt.rcParams['ytick.labelsize'] = 9
plt.rcParams['figure.titlesize'] = 14

COLORS = {'Cammeo': '#2b5c8f', 'Osmancik': '#d96b27'}
PALETTE = [COLORS['Cammeo'], COLORS['Osmancik']]

def load_and_clean_data(filepath='Rice_Cammeo_Osmancik.arff'):
    """Loads ARFF file, cleans string types, exports CSV, and returns DataFrame."""
    print("=" * 70)
    print("1. LOADING AND CLEANING DATASET")
    print("=" * 70)
    
    data, meta = arff.loadarff(filepath)
    df = pd.DataFrame(data)
    
    # Decode byte string column
    df['Class'] = df['Class'].str.decode('utf-8')
    
    # Cast integers where appropriate according to schema
    df['Area'] = df['Area'].astype(int)
    df['Convex_Area'] = df['Convex_Area'].astype(int)
    
    # Save clean CSV
    csv_path = 'rice_cleaned.csv'
    df.to_csv(csv_path, index=False)
    print(f"Dataset successfully loaded. Shape: {df.shape} (Rows: {df.shape[0]}, Columns: {df.shape[1]})")
    print(f"Saved cleaned data to: {csv_path}")
    print(f"Missing values count: {df.isnull().sum().sum()}")
    print(f"Duplicate rows: {df.duplicated().sum()}")
    
    return df

def feature_engineering(df):
    """Computes morphological features relevant to agricultural grain analysis."""
    print("\n" + "=" * 70)
    print("2. FEATURE ENGINEERING (MORPHOLOGICAL INDICES)")
    print("=" * 70)
    
    df_feat = df.copy()
    
    # 1. Aspect Ratio (Major Axis / Minor Axis)
    df_feat['Aspect_Ratio'] = df_feat['Major_Axis_Length'] / df_feat['Minor_Axis_Length']
    
    # 2. Compactness / Form Factor (4 * pi * Area / Perimeter^2) - measures circularity
    df_feat['Compactness'] = (4 * np.pi * df_feat['Area']) / (df_feat['Perimeter'] ** 2)
    
    # 3. Solidity / Convexity (Area / Convex_Area) - measures contour irregularity
    df_feat['Solidity'] = df_feat['Area'] / df_feat['Convex_Area']
    
    # 4. Equivalent Diameter (diameter of a circle with same area)
    df_feat['Equivalent_Diameter'] = np.sqrt((4 * df_feat['Area']) / np.pi)
    
    # 5. Roundness (4 * Area / (pi * Major_Axis^2))
    df_feat['Roundness'] = (4 * df_feat['Area']) / (np.pi * (df_feat['Major_Axis_Length'] ** 2))
    
    print("Engineered 5 new morphological indicators:")
    print(" - Aspect_Ratio (Major / Minor Axis)")
    print(" - Compactness (4*pi*Area / Perimeter^2)")
    print(" - Solidity (Area / Convex_Area)")
    print(" - Equivalent_Diameter (sqrt(4*Area / pi))")
    print(" - Roundness (4*Area / (pi*Major_Axis^2))")
    
    return df_feat

def compute_statistics(df, df_feat):
    """Calculates comprehensive parametric, non-parametric, and effect size stats."""
    print("\n" + "=" * 70)
    print("3. STATISTICAL SUMMARY AND HYPOTHESIS TESTING")
    print("=" * 70)
    
    features = [c for c in df.columns if c != 'Class']
    stats_list = []
    
    for f in features:
        cammeo = df[df['Class'] == 'Cammeo'][f]
        osmancik = df[df['Class'] == 'Osmancik'][f]
        
        # Normality tests
        stat_shapiro_c, p_shapiro_c = stats.shapiro(cammeo)
        stat_shapiro_o, p_shapiro_o = stats.shapiro(osmancik)
        
        # Two-sample t-test (Welch's t-test)
        t_stat, p_val_t = stats.ttest_ind(cammeo, osmancik, equal_var=False)
        
        # Mann-Whitney U test
        u_stat, p_val_u = stats.mannwhitneyu(cammeo, osmancik)
        
        # Cohen's d (Effect Size)
        n1, n2 = len(cammeo), len(osmancik)
        s1, s2 = np.var(cammeo, ddof=1), np.var(osmancik, ddof=1)
        pooled_std = np.sqrt(((n1 - 1) * s1 + (n2 - 1) * s2) / (n1 + n2 - 2))
        cohens_d = (np.mean(cammeo) - np.mean(osmancik)) / pooled_std
        
        stats_list.append({
            'Feature': f,
            'Cammeo_Mean': np.mean(cammeo),
            'Cammeo_Std': np.std(cammeo, ddof=1),
            'Osmancik_Mean': np.mean(osmancik),
            'Osmancik_Std': np.std(osmancik, ddof=1),
            'Mean_Diff': np.mean(cammeo) - np.mean(osmancik),
            'Welch_t_stat': t_stat,
            't_test_p_val': p_val_t,
            'MannWhitney_p_val': p_val_u,
            'Cohens_d': cohens_d,
            'Cammeo_Shapiro_p': p_shapiro_c,
            'Osmancik_Shapiro_p': p_shapiro_o
        })
        
    stats_df = pd.DataFrame(stats_list)
    print(stats_df[['Feature', 'Cammeo_Mean', 'Osmancik_Mean', 'Cohens_d', 't_test_p_val']].to_string(index=False))
    return stats_df

def generate_visualizations(df, df_feat, output_dir='eda_plots'):
    """Generates a complete suite of publication-ready visualizations."""
    print("\n" + "=" * 70)
    print("4. GENERATING PUBLICATION-QUALITY VISUALIZATIONS")
    print("=" * 70)
    os.makedirs(output_dir, exist_ok=True)
    
    raw_features = [c for c in df.columns if c != 'Class']
    
    # -------------------------------------------------------------
    # 01. Class Distribution & Relative Frequency
    # -------------------------------------------------------------
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    counts = df['Class'].value_counts()
    
    # Bar plot
    sns.barplot(x=counts.index, y=counts.values, ax=axes[0], palette=PALETTE, edgecolor='black', alpha=0.85)
    axes[0].set_title("Rice Variety Class Sample Counts", fontweight='bold')
    axes[0].set_ylabel("Count")
    axes[0].set_xlabel("Rice Variety")
    for i, count in enumerate(counts.values):
        pct = count / len(df) * 100
        axes[0].annotate(f"{count:,}\n({pct:.1f}%)", xy=(i, count / 2),
                         ha='center', va='center', color='white', fontweight='bold', fontsize=12)
        
    # Donut Chart
    axes[1].pie(counts.values, labels=counts.index, autopct='%1.1f%%', startangle=140,
                colors=PALETTE, wedgeprops=dict(width=0.45, edgecolor='w', linewidth=2),
                textprops={'fontsize': 11, 'weight': 'bold'})
    axes[1].set_title("Proportion of Varieties", fontweight='bold')
    
    plt.tight_layout()
    fig.savefig(f"{output_dir}/01_class_distribution.png", dpi=300)
    plt.close()
    print("Saved: 01_class_distribution.png")

    # -------------------------------------------------------------
    # 02. Univariate Distributions (Histograms & KDE)
    # -------------------------------------------------------------
    fig, axes = plt.subplots(3, 3, figsize=(16, 12))
    axes = axes.flatten()
    
    for i, col in enumerate(raw_features):
        sns.histplot(data=df, x=col, hue='Class', kde=True, ax=axes[i],
                     palette=PALETTE, element='step', common_norm=False, alpha=0.4)
        axes[i].set_title(f"Distribution: {col}", fontweight='bold')
        axes[i].set_xlabel(col)
        axes[i].set_ylabel("Frequency")
        
    # Hide unused subplots
    for j in range(len(raw_features), len(axes)):
        fig.delaxes(axes[j])
        
    fig.suptitle("Univariate Feature Distributions by Rice Variety", fontsize=16, fontweight='bold', y=1.00)
    plt.tight_layout()
    fig.savefig(f"{output_dir}/02_univariate_distributions.png", dpi=300)
    plt.close()
    print("Saved: 02_univariate_distributions.png")

    # -------------------------------------------------------------
    # 03. Boxplots with Outlier Demarcation
    # -------------------------------------------------------------
    fig, axes = plt.subplots(2, 4, figsize=(18, 9))
    axes = axes.flatten()
    
    for i, col in enumerate(raw_features):
        sns.boxplot(data=df, x='Class', y=col, ax=axes[i], palette=PALETTE,
                    width=0.5, boxprops=dict(alpha=0.8), flierprops=dict(marker='o', markersize=3, alpha=0.5))
        axes[i].set_title(f"{col} by Variety", fontweight='bold')
        axes[i].set_xlabel("")
        axes[i].set_ylabel(col)
        
    for j in range(len(raw_features), len(axes)):
        fig.delaxes(axes[j])
        
    fig.suptitle("Morphological Feature Boxplots (Cammeo vs. Osmancik)", fontsize=16, fontweight='bold', y=1.00)
    plt.tight_layout()
    fig.savefig(f"{output_dir}/03_boxplots_by_class.png", dpi=300)
    plt.close()
    print("Saved: 03_boxplots_by_class.png")

    # -------------------------------------------------------------
    # 04. Violin Plots with Kernel Density Profiles
    # -------------------------------------------------------------
    fig, axes = plt.subplots(2, 4, figsize=(18, 9))
    axes = axes.flatten()
    
    for i, col in enumerate(raw_features):
        sns.violinplot(data=df, x='Class', y=col, ax=axes[i], palette=PALETTE,
                       inner='quartile', cut=0, alpha=0.85)
        axes[i].set_title(f"Density Profile: {col}", fontweight='bold')
        axes[i].set_xlabel("")
        axes[i].set_ylabel(col)
        
    for j in range(len(raw_features), len(axes)):
        fig.delaxes(axes[j])
        
    fig.suptitle("Violin Plots Showing Shape, Density & Quartiles", fontsize=16, fontweight='bold', y=1.00)
    plt.tight_layout()
    fig.savefig(f"{output_dir}/04_violin_distributions.png", dpi=300)
    plt.close()
    print("Saved: 04_violin_distributions.png")

    # -------------------------------------------------------------
    # 05. Correlation Matrices (Pearson & Spearman)
    # -------------------------------------------------------------
    fig, axes = plt.subplots(1, 2, figsize=(16, 7))
    num_df = df[raw_features]
    
    pearson_corr = num_df.corr(method='pearson')
    spearman_corr = num_df.corr(method='spearman')
    
    mask = np.triu(np.ones_like(pearson_corr, dtype=bool))
    
    sns.heatmap(pearson_corr, mask=mask, annot=True, fmt=".2f", cmap="vlag", vmin=-1, vmax=1,
                center=0, square=True, linewidths=.5, cbar_kws={"shrink": .8}, ax=axes[0])
    axes[0].set_title("Pearson Linear Correlation Matrix", fontweight='bold')
    
    sns.heatmap(spearman_corr, mask=mask, annot=True, fmt=".2f", cmap="vlag", vmin=-1, vmax=1,
                center=0, square=True, linewidths=.5, cbar_kws={"shrink": .8}, ax=axes[1])
    axes[1].set_title("Spearman Rank Correlation Matrix", fontweight='bold')
    
    plt.tight_layout()
    fig.savefig(f"{output_dir}/05_correlation_heatmap.png", dpi=300)
    plt.close()
    print("Saved: 05_correlation_heatmap.png")

    # -------------------------------------------------------------
    # 06. Scatter Plot: Major Axis vs Minor Axis with Marginals
    # -------------------------------------------------------------
    g = sns.JointGrid(data=df, x="Minor_Axis_Length", y="Major_Axis_Length", hue="Class", palette=PALETTE, height=8)
    g.plot_joint(sns.scatterplot, alpha=0.6, s=30, edgecolor='none')
    g.plot_marginals(sns.kdeplot, fill=True, common_norm=False, alpha=0.5)
    g.fig.suptitle("Major Axis vs. Minor Axis Grain Dimensions", fontsize=14, fontweight='bold', y=1.02)
    g.savefig(f"{output_dir}/06_scatter_major_vs_minor.png", dpi=300)
    plt.close()
    print("Saved: 06_scatter_major_vs_minor.png")

    # -------------------------------------------------------------
    # 07. Pairplot (Key Morphological Features)
    # -------------------------------------------------------------
    key_features = ['Area', 'Major_Axis_Length', 'Minor_Axis_Length', 'Eccentricity', 'Class']
    pair_g = sns.pairplot(df[key_features], hue='Class', palette=PALETTE,
                          diag_kind='kde', plot_kws={'alpha': 0.5, 's': 20, 'edgecolor': 'none'},
                          corner=True)
    pair_g.fig.suptitle("Pairwise Relationships of Key Morphological Features", fontsize=15, fontweight='bold', y=1.02)
    pair_g.savefig(f"{output_dir}/07_pairplot_morphology.png", dpi=300)
    plt.close()
    print("Saved: 07_pairplot_morphology.png")

    # -------------------------------------------------------------
    # 08. Dimensionality Reduction: PCA Biplot & Scree
    # -------------------------------------------------------------
    X = df[raw_features]
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    pca = PCA()
    X_pca = pca.fit_transform(X_scaled)
    var_exp = pca.explained_variance_ratio_ * 100
    cum_var_exp = np.cumsum(var_exp)
    
    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    
    # Scree Plot
    axes[0].bar(range(1, len(var_exp) + 1), var_exp, alpha=0.7, color='#2b5c8f', label='Individual Variance')
    axes[0].step(range(1, len(var_exp) + 1), cum_var_exp, where='mid', color='#d96b27', linewidth=2.5, label='Cumulative Variance')
    axes[0].set_xlabel('Principal Component Index')
    axes[0].set_ylabel('Explained Variance Ratio (%)')
    axes[0].set_title('PCA Scree & Cumulative Variance', fontweight='bold')
    axes[0].set_xticks(range(1, len(var_exp) + 1))
    axes[0].legend(loc='best')
    for i, v in enumerate(cum_var_exp):
        axes[0].annotate(f"{v:.1f}%", xy=(i+1, v), xytext=(0, 4), textcoords="offset points", ha='center', fontsize=9)
        
    # PCA 2D Scatter with Loadings Vector Biplot
    for cls, color in COLORS.items():
        idx = df['Class'] == cls
        axes[1].scatter(X_pca[idx, 0], X_pca[idx, 1], c=color, label=cls, alpha=0.5, s=25)
        
    # Plot feature vectors on PCA space
    scale_factor = 3.5
    for i, feature in enumerate(raw_features):
        axes[1].arrow(0, 0, pca.components_[0, i] * scale_factor, pca.components_[1, i] * scale_factor,
                     color='darkred', alpha=0.7, head_width=0.1, head_length=0.1)
        axes[1].text(pca.components_[0, i] * scale_factor * 1.12,
                     pca.components_[1, i] * scale_factor * 1.12,
                     feature, color='darkred', ha='center', va='center', fontweight='bold', fontsize=9)
        
    axes[1].set_xlabel(f"PC1 ({var_exp[0]:.1f}% Variance)")
    axes[1].set_ylabel(f"PC2 ({var_exp[1]:.1f}% Variance)")
    axes[1].set_title("PCA 2D Projection with Feature Loadings Biplot", fontweight='bold')
    axes[1].legend(title="Rice Variety")
    
    plt.tight_layout()
    fig.savefig(f"{output_dir}/08_pca_projection.png", dpi=300)
    plt.close()
    print("Saved: 08_pca_projection.png")

    # -------------------------------------------------------------
    # 09. Dimensionality Reduction: t-SNE Manifold
    # -------------------------------------------------------------
    print("Computing t-SNE 2D embedding (perplexity=35, random_state=42)...")
    tsne = TSNE(n_components=2, perplexity=35, random_state=42, n_iter_without_progress=300)
    X_tsne = tsne.fit_transform(X_scaled)
    
    fig, ax = plt.subplots(figsize=(8, 6))
    for cls, color in COLORS.items():
        idx = df['Class'] == cls
        ax.scatter(X_tsne[idx, 0], X_tsne[idx, 1], c=color, label=cls, alpha=0.55, s=25)
    ax.set_title("t-SNE 2D Manifold Embedding of Rice Varieties", fontweight='bold', fontsize=13)
    ax.set_xlabel("t-SNE Dimension 1")
    ax.set_ylabel("t-SNE Dimension 2")
    ax.legend(title="Rice Variety")
    
    plt.tight_layout()
    fig.savefig(f"{output_dir}/09_tsne_projection.png", dpi=300)
    plt.close()
    print("Saved: 09_tsne_projection.png")

    # -------------------------------------------------------------
    # 10. Engineered Features Distributions
    # -------------------------------------------------------------
    eng_cols = ['Aspect_Ratio', 'Compactness', 'Solidity', 'Equivalent_Diameter', 'Roundness']
    fig, axes = plt.subplots(2, 3, figsize=(16, 9))
    axes = axes.flatten()
    
    for i, col in enumerate(eng_cols):
        sns.boxplot(data=df_feat, x='Class', y=col, ax=axes[i], palette=PALETTE, width=0.5, boxprops=dict(alpha=0.85))
        axes[i].set_title(f"Engineered: {col}", fontweight='bold')
        axes[i].set_xlabel("")
        
    for j in range(len(eng_cols), len(axes)):
        fig.delaxes(axes[j])
        
    fig.suptitle("Engineered Morphological Feature Comparison", fontsize=15, fontweight='bold', y=1.01)
    plt.tight_layout()
    fig.savefig(f"{output_dir}/10_engineered_features.png", dpi=300)
    plt.close()
    print("Saved: 10_engineered_features.png")

    # -------------------------------------------------------------
    # 11. Feature Importance & Mutual Information
    # -------------------------------------------------------------
    y = (df['Class'] == 'Cammeo').astype(int)
    
    # Mutual Information
    mi_scores = mutual_info_classif(X_scaled, y, random_state=42)
    mi_series = pd.Series(mi_scores, index=raw_features).sort_values(ascending=True)
    
    # Random Forest Feature Importance
    rf = RandomForestClassifier(n_estimators=100, random_state=42)
    rf.fit(X_scaled, y)
    rf_series = pd.Series(rf.feature_importances_, index=raw_features).sort_values(ascending=True)
    
    fig, axes = plt.subplots(1, 2, figsize=(15, 6))
    
    mi_series.plot(kind='barh', ax=axes[0], color='#2b5c8f', edgecolor='black', alpha=0.85)
    axes[0].set_title("Mutual Information Score with Class", fontweight='bold')
    axes[0].set_xlabel("Mutual Information")
    for i, val in enumerate(mi_series):
        axes[0].text(val + 0.005, i, f"{val:.3f}", va='center', fontweight='bold', fontsize=9)
        
    rf_series.plot(kind='barh', ax=axes[1], color='#d96b27', edgecolor='black', alpha=0.85)
    axes[1].set_title("Random Forest Gini Feature Importance", fontweight='bold')
    axes[1].set_xlabel("Importance Weight")
    for i, val in enumerate(rf_series):
        axes[1].text(val + 0.005, i, f"{val:.3f}", va='center', fontweight='bold', fontsize=9)
        
    plt.tight_layout()
    fig.savefig(f"{output_dir}/11_feature_importance_mi.png", dpi=300)
    plt.close()
    print("Saved: 11_feature_importance_mi.png")
    
    return mi_series, rf_series

def evaluate_ml_baselines(df):
    """Executes 5-fold cross-validated baseline machine learning benchmarks."""
    print("\n" + "=" * 70)
    print("5. MACHINE LEARNING BASELINE CLASSIFICATION")
    print("=" * 70)
    
    X = df.drop(columns=['Class'])
    y = (df['Class'] == 'Cammeo').astype(int)
    
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    
    models = {
        'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
        'Random Forest (100 trees)': RandomForestClassifier(n_estimators=100, random_state=42)
    }
    
    benchmark_results = {}
    for name, model in models.items():
        acc_scores = cross_val_score(model, X_scaled, y, cv=cv, scoring='accuracy')
        f1_scores = cross_val_score(model, X_scaled, y, cv=cv, scoring='f1')
        roc_scores = cross_val_score(model, X_scaled, y, cv=cv, scoring='roc_auc')
        
        benchmark_results[name] = {
            'Accuracy': (acc_scores.mean(), acc_scores.std()),
            'F1-Score': (f1_scores.mean(), f1_scores.std()),
            'ROC-AUC': (roc_scores.mean(), roc_scores.std())
        }
        
        print(f"\nModel: {name}")
        print(f" - Accuracy:  {acc_scores.mean():.4f} (+/- {acc_scores.std():.4f})")
        print(f" - F1-Score:  {f1_scores.mean():.4f} (+/- {f1_scores.std():.4f})")
        print(f" - ROC-AUC:   {roc_scores.mean():.4f} (+/- {roc_scores.std():.4f})")
        
    return benchmark_results

def outlier_detection(df):
    """Calculates outlier proportions using IQR and Z-Score methods."""
    print("\n" + "=" * 70)
    print("6. OUTLIER ANALYSIS")
    print("=" * 70)
    
    num_cols = [c for c in df.columns if c != 'Class']
    outlier_summary = []
    
    for col in num_cols:
        q1 = df[col].quantile(0.25)
        q3 = df[col].quantile(0.75)
        iqr = q3 - q1
        lower_bound = q1 - 1.5 * iqr
        upper_bound = q3 + 1.5 * iqr
        
        outliers_iqr = df[(df[col] < lower_bound) | (df[col] > upper_bound)]
        
        z_scores = np.abs(stats.zscore(df[col]))
        outliers_z = df[z_scores > 3]
        
        outlier_summary.append({
            'Feature': col,
            'IQR_Outliers': len(outliers_iqr),
            'IQR_Pct': (len(outliers_iqr) / len(df)) * 100,
            'ZScore_3_Outliers': len(outliers_z),
            'ZScore_3_Pct': (len(outliers_z) / len(df)) * 100,
            'Lower_Bound': lower_bound,
            'Upper_Bound': upper_bound
        })
        
    outlier_df = pd.DataFrame(outlier_summary)
    print(outlier_df.to_string(index=False))
    return outlier_df

if __name__ == '__main__':
    df = load_and_clean_data()
    df_feat = feature_engineering(df)
    stats_df = compute_statistics(df, df_feat)
    outlier_df = outlier_detection(df)
    mi_series, rf_series = generate_visualizations(df, df_feat)
    benchmark_results = evaluate_ml_baselines(df)
    print("\n" + "=" * 70)
    print("EDA PIPELINE COMPLETED SUCCESSFULLY!")
    print("=" * 70)
