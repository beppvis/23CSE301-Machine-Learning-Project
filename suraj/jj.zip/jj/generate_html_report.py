"""
Generates a standalone, modern, interactive HTML report for the Rice Dataset EDA.
Embeds high-resolution images, statistical tables, interactive tabs, KPI cards,
and dark/light mode toggle.
"""

import base64
import os
import pandas as pd
import numpy as np

def get_base64_img(path):
    if os.path.exists(path):
        with open(path, 'rb') as f:
            encoded = base64.b64encode(f.read()).decode('utf-8')
            return f"data:image/png;base64,{encoded}"
    return ""

img_files = {
    'class_dist': 'eda_plots/01_class_distribution.png',
    'univariate': 'eda_plots/02_univariate_distributions.png',
    'boxplots': 'eda_plots/03_boxplots_by_class.png',
    'violin': 'eda_plots/04_violin_distributions.png',
    'corr': 'eda_plots/05_correlation_heatmap.png',
    'scatter': 'eda_plots/06_scatter_major_vs_minor.png',
    'pairplot': 'eda_plots/07_pairplot_morphology.png',
    'pca': 'eda_plots/08_pca_projection.png',
    'tsne': 'eda_plots/09_tsne_projection.png',
    'engineered': 'eda_plots/10_engineered_features.png',
    'importance': 'eda_plots/11_feature_importance_mi.png'
}

b64 = {k: get_base64_img(v) for k, v in img_files.items()}

html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rice Grain Morphology EDA Dashboard (Cammeo vs. Osmancik)</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --bg: #0b0f19;
            --surface: #131b2e;
            --surface-card: rgba(26, 35, 58, 0.7);
            --border: rgba(255, 255, 255, 0.08);
            --text-primary: #f1f5f9;
            --text-secondary: #94a3b8;
            --accent-cammeo: #38bdf8;
            --accent-cammeo-glow: rgba(56, 189, 248, 0.25);
            --accent-osmancik: #fb923c;
            --accent-osmancik-glow: rgba(251, 146, 60, 0.25);
            --primary-gradient: linear-gradient(135deg, #38bdf8 0%, #818cf8 100%);
            --badge-bg: rgba(56, 189, 248, 0.12);
            --font-main: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
            --font-mono: 'JetBrains Mono', monospace;
            --radius-lg: 16px;
            --radius-md: 10px;
            --radius-sm: 6px;
        }}

        * {{
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }}

        body {{
            font-family: var(--font-main);
            background-color: var(--bg);
            color: var(--text-primary);
            line-height: 1.6;
            padding: 30px 20px;
            min-height: 100vh;
        }}

        .container {{
            max-width: 1400px;
            margin: 0 auto;
        }}

        /* Header */
        header {{
            background: linear-gradient(180deg, rgba(30, 41, 67, 0.8) 0%, rgba(19, 27, 46, 0.8) 100%);
            backdrop-filter: blur(16px);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 36px 40px;
            margin-bottom: 28px;
            box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.5);
            position: relative;
            overflow: hidden;
        }}

        header::before {{
            content: '';
            position: absolute;
            top: -100px;
            right: -100px;
            width: 300px;
            height: 300px;
            background: radial-gradient(circle, rgba(56, 189, 248, 0.15) 0%, transparent 70%);
            pointer-events: none;
        }}

        .header-badge {{
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 14px;
            background: var(--badge-bg);
            border: 1px solid rgba(56, 189, 248, 0.3);
            border-radius: 999px;
            color: var(--accent-cammeo);
            font-size: 0.82rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 12px;
        }}

        h1 {{
            font-size: 2.3rem;
            font-weight: 800;
            letter-spacing: -0.02em;
            background: linear-gradient(135deg, #ffffff 0%, #cbd5e1 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 8px;
        }}

        p.subtitle {{
            color: var(--text-secondary);
            font-size: 1.05rem;
            max-width: 850px;
        }}

        /* KPI Metrics Grid */
        .kpi-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 18px;
            margin-bottom: 30px;
        }}

        .kpi-card {{
            background: var(--surface-card);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            padding: 22px;
            backdrop-filter: blur(12px);
            transition: transform 0.2s ease, border-color 0.2s ease, box-shadow 0.2s ease;
        }}

        .kpi-card:hover {{
            transform: translateY(-3px);
            border-color: rgba(56, 189, 248, 0.4);
            box-shadow: 0 10px 25px -10px rgba(56, 189, 248, 0.2);
        }}

        .kpi-label {{
            font-size: 0.85rem;
            color: var(--text-secondary);
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            margin-bottom: 6px;
        }}

        .kpi-value {{
            font-size: 1.9rem;
            font-weight: 800;
            color: #ffffff;
            font-family: var(--font-mono);
            letter-spacing: -0.03em;
        }}

        .kpi-subtext {{
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin-top: 4px;
        }}

        /* Navigation Tabs */
        .tabs-nav {{
            display: flex;
            gap: 8px;
            margin-bottom: 24px;
            background: rgba(19, 27, 46, 0.8);
            padding: 6px;
            border-radius: 12px;
            border: 1px solid var(--border);
            overflow-x: auto;
        }}

        .tab-btn {{
            background: transparent;
            border: none;
            color: var(--text-secondary);
            padding: 10px 18px;
            font-size: 0.92rem;
            font-weight: 600;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s ease;
            white-space: nowrap;
            display: flex;
            align-items: center;
            gap: 8px;
        }}

        .tab-btn:hover {{
            color: var(--text-primary);
            background: rgba(255, 255, 255, 0.05);
        }}

        .tab-btn.active {{
            background: var(--primary-gradient);
            color: #0b0f19;
            font-weight: 700;
            box-shadow: 0 4px 15px rgba(56, 189, 248, 0.3);
        }}

        /* Tab Content */
        .tab-pane {{
            display: none;
            animation: fadeIn 0.3s ease forwards;
        }}

        .tab-pane.active {{
            display: block;
        }}

        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(6px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        /* Content Sections */
        .section-card {{
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 30px;
            margin-bottom: 28px;
            box-shadow: 0 10px 30px -10px rgba(0, 0, 0, 0.4);
        }}

        .section-header {{
            margin-bottom: 20px;
            border-bottom: 1px solid var(--border);
            padding-bottom: 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}

        .section-header h2 {{
            font-size: 1.45rem;
            font-weight: 700;
            color: #ffffff;
            display: flex;
            align-items: center;
            gap: 10px;
        }}

        .section-desc {{
            color: var(--text-secondary);
            font-size: 0.95rem;
            margin-bottom: 20px;
        }}

        .img-container {{
            width: 100%;
            background: rgba(11, 15, 25, 0.6);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            padding: 12px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 14px;
        }}

        .img-container img {{
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            transition: transform 0.2s ease;
        }}

        .grid-2 {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 24px;
        }}

        @media (max-width: 900px) {{
            .grid-2 {{
                grid-template-columns: 1fr;
            }}
            header {{
                padding: 24px;
            }}
            h1 {{
                font-size: 1.8rem;
            }}
        }}

        /* Tables */
        .table-responsive {{
            overflow-x: auto;
            margin: 16px 0;
            border-radius: var(--radius-md);
            border: 1px solid var(--border);
        }}

        table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 0.88rem;
            text-align: left;
            background: rgba(15, 23, 42, 0.5);
        }}

        th {{
            background: rgba(30, 41, 67, 0.9);
            color: var(--text-primary);
            padding: 12px 16px;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.76rem;
            letter-spacing: 0.05em;
            border-bottom: 1px solid var(--border);
        }}

        td {{
            padding: 12px 16px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.04);
            color: #cbd5e1;
        }}

        tr:hover td {{
            background: rgba(255, 255, 255, 0.03);
        }}

        .badge-cammeo {{
            background: var(--accent-cammeo-glow);
            color: var(--accent-cammeo);
            padding: 4px 10px;
            border-radius: 6px;
            font-weight: 600;
            font-size: 0.8rem;
        }}

        .badge-osmancik {{
            background: var(--accent-osmancik-glow);
            color: var(--accent-osmancik);
            padding: 4px 10px;
            border-radius: 6px;
            font-weight: 600;
            font-size: 0.8rem;
        }}

        .badge-pill {{
            padding: 3px 8px;
            border-radius: 999px;
            font-size: 0.75rem;
            font-weight: 600;
        }}

        .badge-huge {{
            background: rgba(34, 197, 94, 0.15);
            color: #4ade80;
            border: 1px solid rgba(34, 197, 94, 0.3);
        }}

        .badge-large {{
            background: rgba(56, 189, 248, 0.15);
            color: #38bdf8;
            border: 1px solid rgba(56, 189, 248, 0.3);
        }}

        .badge-mod {{
            background: rgba(245, 158, 11, 0.15);
            color: #fbbf24;
            border: 1px solid rgba(245, 158, 11, 0.3);
        }}

        /* Key Takeaway Cards */
        .callout {{
            background: rgba(56, 189, 248, 0.08);
            border-left: 4px solid var(--accent-cammeo);
            border-radius: 0 var(--radius-md) var(--radius-md) 0;
            padding: 16px 20px;
            margin: 18px 0;
            font-size: 0.95rem;
        }}

        .callout strong {{
            color: var(--accent-cammeo);
        }}

        .callout-warning {{
            background: rgba(251, 146, 60, 0.08);
            border-left-color: var(--accent-osmancik);
        }}

        .callout-warning strong {{
            color: var(--accent-osmancik);
        }}
    </style>
</head>
<body>

<div class="container">
    <!-- Header -->
    <header>
        <div class="header-badge">🌱 AgriTech & Computer Vision EDA</div>
        <h1>Rice Variety Morphological Analysis</h1>
        <p class="subtitle">Exploratory Data Analysis, Morphological Feature Engineering, Multicollinearity Diagnostics, and Machine Learning Benchmarking on <strong>Cammeo</strong> and <strong>Osmancik</strong> grain cultivars.</p>
    </header>

    <!-- KPI Metric Cards -->
    <div class="kpi-grid">
        <div class="kpi-card">
            <div class="kpi-label">Total Grain Specimens</div>
            <div class="kpi-value">3,810</div>
            <div class="kpi-subtext">No missing values | 0 duplicates</div>
        </div>
        <div class="kpi-card">
            <div class="kpi-label">Cammeo Grains</div>
            <div class="kpi-value" style="color: var(--accent-cammeo);">1,630</div>
            <div class="kpi-subtext">42.8% of dataset (Long-grain)</div>
        </div>
        <div class="kpi-card">
            <div class="kpi-label">Osmancik Grains</div>
            <div class="kpi-value" style="color: var(--accent-osmancik);">2,180</div>
            <div class="kpi-subtext">57.2% of dataset (Medium-grain)</div>
        </div>
        <div class="kpi-card">
            <div class="kpi-label">Top Discriminator</div>
            <div class="kpi-value">Major Axis</div>
            <div class="kpi-subtext">Cohen's d = 2.98 (Extraordinary)</div>
        </div>
        <div class="kpi-card">
            <div class="kpi-label">Linear Baseline Acc</div>
            <div class="kpi-value" style="color: #4ade80;">92.8%</div>
            <div class="kpi-subtext">ROC-AUC: 0.9790 (5-Fold CV)</div>
        </div>
    </div>

    <!-- Navigation Tabs -->
    <nav class="tabs-nav">
        <button class="tab-btn active" onclick="switchTab(event, 'tab-overview')">📋 Overview & Balance</button>
        <button class="tab-btn" onclick="switchTab(event, 'tab-distributions')">📊 Distributions & Density</button>
        <button class="tab-btn" onclick="switchTab(event, 'tab-morphology')">🔬 Class Separation</button>
        <button class="tab-btn" onclick="switchTab(event, 'tab-correlations')">🔗 Correlations & VIF</button>
        <button class="tab-btn" onclick="switchTab(event, 'tab-projections')">🌐 PCA & t-SNE</button>
        <button class="tab-btn" onclick="switchTab(event, 'tab-engineering')">🛠️ Feature Engineering</button>
        <button class="tab-btn" onclick="switchTab(event, 'tab-ml')">🤖 ML Benchmark</button>
    </nav>

    <!-- Tab 1: Overview & Balance -->
    <div id="tab-overview" class="tab-pane active">
        <div class="section-card">
            <div class="section-header">
                <h2>Class Distribution & Dataset Representation</h2>
            </div>
            <p class="section-desc">The dataset exhibits mild, healthy class balance (~57% Osmancik to ~43% Cammeo), eliminating the need for aggressive synthetic sampling like SMOTE. Standard stratified splits will maintain robust generalization.</p>
            <div class="img-container">
                <img src="{b64['class_dist']}" alt="Class Distribution Chart">
            </div>
            
            <div class="callout">
                <strong>Domain Context:</strong> Cammeo is historically known in Mediterranean agriculture as a premium, long-grained rice with elongated oval kernel geometry. Osmancik is a widely cultivated Turkish variety engineered by the Trakya Agricultural Research Institute, known for its sturdier, rounder, medium kernel length.
            </div>
        </div>

        <div class="section-card">
            <div class="section-header">
                <h2>Data Dictionary & Morphological Attributes</h2>
            </div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Attribute</th>
                            <th>Data Type</th>
                            <th>Unit</th>
                            <th>Physical Definition</th>
                            <th>Role in Classification</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>Area</strong></td>
                            <td>Integer</td>
                            <td>px²</td>
                            <td>Total number of pixels within the grain silhouette.</td>
                            <td>Primary size indicator; Cammeo is ~22.6% larger on average.</td>
                        </tr>
                        <tr>
                            <td><strong>Perimeter</strong></td>
                            <td>Continuous Real</td>
                            <td>px</td>
                            <td>Circumference of the grain boundary.</td>
                            <td>High discriminative power; reflects both elongation and scale.</td>
                        </tr>
                        <tr>
                            <td><strong>Major_Axis_Length</strong></td>
                            <td>Continuous Real</td>
                            <td>px</td>
                            <td>Longest distance between two points along grain symmetry axis.</td>
                            <td>Single strongest discriminator (Cohen's d = 2.98).</td>
                        </tr>
                        <tr>
                            <td><strong>Minor_Axis_Length</strong></td>
                            <td>Continuous Real</td>
                            <td>px</td>
                            <td>Longest distance perpendicular to the major axis.</td>
                            <td>Moderate discriminator; grains differ more in length than width.</td>
                        </tr>
                        <tr>
                            <td><strong>Eccentricity</strong></td>
                            <td>Continuous Real</td>
                            <td>Ratio [0, 1]</td>
                            <td>Ratio of distance between foci to major axis length.</td>
                            <td>Cammeo is noticeably more elliptical (0.901 vs. 0.876).</td>
                        </tr>
                        <tr>
                            <td><strong>Convex_Area</strong></td>
                            <td>Integer</td>
                            <td>px²</td>
                            <td>Area of the minimal convex hull bounding the grain.</td>
                            <td>Nearly collinear with Area (r = 0.999), reflecting smooth convex grains.</td>
                        </tr>
                        <tr>
                            <td><strong>Extent</strong></td>
                            <td>Continuous Real</td>
                            <td>Ratio (0, 1]</td>
                            <td>Area of grain divided by area of bounding box.</td>
                            <td>Low discriminability; both varieties fill bounding boxes similarly.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Tab 2: Distributions -->
    <div id="tab-distributions" class="tab-pane">
        <div class="section-card">
            <div class="section-header">
                <h2>Univariate Histograms & Kernel Density Estimates</h2>
            </div>
            <p class="section-desc">Examining the probability density functions reveals bimodal behavior across features like <code>Major_Axis_Length</code> and <code>Perimeter</code>, where the two variety clusters diverge.</p>
            <div class="img-container">
                <img src="{b64['univariate']}" alt="Univariate Distributions">
            </div>
        </div>

        <div class="section-card">
            <div class="section-header">
                <h2>Violin Density & Quartile Profiles</h2>
            </div>
            <p class="section-desc">Violin plots highlight the internal quartile ranges and the symmetry of distributions for each variety.</p>
            <div class="img-container">
                <img src="{b64['violin']}" alt="Violin Profiles">
            </div>
        </div>
    </div>

    <!-- Tab 3: Class Separation -->
    <div id="tab-morphology" class="tab-pane">
        <div class="section-card">
            <div class="section-header">
                <h2>Hypothesis Testing & Effect Size (Cohen's d)</h2>
            </div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Feature</th>
                            <th>Cammeo Mean (px)</th>
                            <th>Osmancik Mean (px)</th>
                            <th>Mean Difference</th>
                            <th>Welch t-stat</th>
                            <th>p-value</th>
                            <th>Cohen's d</th>
                            <th>Effect Magnitude</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>Major_Axis_Length</strong></td>
                            <td>205.48</td>
                            <td>176.29</td>
                            <td>+29.19</td>
                            <td>91.87</td>
                            <td>&lt; 10⁻³⁰⁰</td>
                            <td>+2.98</td>
                            <td><span class="badge-pill badge-huge">Massive Separation</span></td>
                        </tr>
                        <tr>
                            <td><strong>Perimeter</strong></td>
                            <td>487.44</td>
                            <td>429.42</td>
                            <td>+58.02</td>
                            <td>85.06</td>
                            <td>&lt; 10⁻³⁰⁰</td>
                            <td>+2.76</td>
                            <td><span class="badge-pill badge-huge">Massive Separation</span></td>
                        </tr>
                        <tr>
                            <td><strong>Convex_Area</strong></td>
                            <td>14,494.43</td>
                            <td>11,799.59</td>
                            <td>+2,694.84</td>
                            <td>70.47</td>
                            <td>&lt; 10⁻³⁰⁰</td>
                            <td>+2.29</td>
                            <td><span class="badge-pill badge-huge">Massive Separation</span></td>
                        </tr>
                        <tr>
                            <td><strong>Area</strong></td>
                            <td>14,162.89</td>
                            <td>11,549.78</td>
                            <td>+2,613.11</td>
                            <td>69.61</td>
                            <td>&lt; 10⁻³⁰⁰</td>
                            <td>+2.27</td>
                            <td><span class="badge-pill badge-huge">Massive Separation</span></td>
                        </tr>
                        <tr>
                            <td><strong>Eccentricity</strong></td>
                            <td>0.901</td>
                            <td>0.876</td>
                            <td>+0.025</td>
                            <td>45.83</td>
                            <td>&lt; 10⁻³⁰⁰</td>
                            <td>+1.47</td>
                            <td><span class="badge-pill badge-large">Very Large</span></td>
                        </tr>
                        <tr>
                            <td><strong>Minor_Axis_Length</strong></td>
                            <td>88.77</td>
                            <td>84.48</td>
                            <td>+4.29</td>
                            <td>25.13</td>
                            <td>4.09 × 10⁻¹²³</td>
                            <td>+0.81</td>
                            <td><span class="badge-pill badge-large">Large</span></td>
                        </tr>
                        <tr>
                            <td><strong>Extent</strong></td>
                            <td>0.651</td>
                            <td>0.670</td>
                            <td>-0.018</td>
                            <td>-7.18</td>
                            <td>8.44 × 10⁻¹³</td>
                            <td>-0.24</td>
                            <td><span class="badge-pill badge-mod">Small</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="img-container">
                <img src="{b64['scatter']}" alt="Major vs Minor Axis Scatter">
            </div>
        </div>

        <div class="section-card">
            <div class="section-header">
                <h2>Morphological Pairwise Interactions</h2>
            </div>
            <div class="img-container">
                <img src="{b64['pairplot']}" alt="Pairwise Morphology">
            </div>
        </div>
    </div>

    <!-- Tab 4: Correlations & VIF -->
    <div id="tab-correlations" class="tab-pane">
        <div class="section-card">
            <div class="section-header">
                <h2>Correlation Analysis (Pearson Linear vs. Spearman Rank)</h2>
            </div>
            <p class="section-desc">Both linear and rank correlations show intense association among size-related attributes (Area, Convex_Area, Perimeter, Major_Axis_Length).</p>
            <div class="img-container">
                <img src="{b64['corr']}" alt="Correlation Heatmaps">
            </div>
        </div>

        <div class="section-card">
            <div class="section-header">
                <h2>Multicollinearity & Variance Inflation Factor (VIF)</h2>
            </div>
            <div class="callout callout-warning">
                <strong>Multicollinearity Alert:</strong> <code>Area</code> and <code>Convex_Area</code> exhibit extreme VIF (> 1,000) due to near-identical information content. For linear models, ridge regularizers or pruning <code>Convex_Area</code> is highly recommended.
            </div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Feature</th>
                            <th>VIF Value</th>
                            <th>Collinearity Severity</th>
                            <th>Recommendation</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>Area</strong></td>
                            <td>1,170.53</td>
                            <td><span class="badge-pill badge-huge" style="background:rgba(239,68,68,0.2); color:#f87171;">Extreme</span></td>
                            <td>Retain as primary canonical grain size metric.</td>
                        </tr>
                        <tr>
                            <td><strong>Convex_Area</strong></td>
                            <td>1,047.28</td>
                            <td><span class="badge-pill badge-huge" style="background:rgba(239,68,68,0.2); color:#f87171;">Extreme</span></td>
                            <td>Drop in unregularized GLM / linear models.</td>
                        </tr>
                        <tr>
                            <td><strong>Major_Axis_Length</strong></td>
                            <td>369.95</td>
                            <td><span class="badge-pill badge-huge" style="background:rgba(239,68,68,0.2); color:#f87171;">Severe</span></td>
                            <td>Keep: Crucial top discriminator between varieties.</td>
                        </tr>
                        <tr>
                            <td><strong>Perimeter</strong></td>
                            <td>233.03</td>
                            <td><span class="badge-pill badge-huge" style="background:rgba(239,68,68,0.2); color:#f87171;">Severe</span></td>
                            <td>Can be retained or replaced by compactness.</td>
                        </tr>
                        <tr>
                            <td><strong>Minor_Axis_Length</strong></td>
                            <td>179.74</td>
                            <td><span class="badge-pill badge-mod">High</span></td>
                            <td>Provides orthogonal width dimension.</td>
                        </tr>
                        <tr>
                            <td><strong>Eccentricity</strong></td>
                            <td>50.72</td>
                            <td><span class="badge-pill badge-mod">Moderate</span></td>
                            <td>Non-linear shape aspect.</td>
                        </tr>
                        <tr>
                            <td><strong>Extent</strong></td>
                            <td>1.14</td>
                            <td><span class="badge-pill badge-huge">Completely Independent</span></td>
                            <td>Zero multicollinearity with size features.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Tab 5: PCA & t-SNE -->
    <div id="tab-projections" class="tab-pane">
        <div class="section-card">
            <div class="section-header">
                <h2>Principal Component Analysis (PCA) & Scree Plot</h2>
            </div>
            <p class="section-desc">PC1 accounts for <strong>74.3%</strong> of total morphological variance, primarily driven by overall grain size. PC2 captures an additional <strong>22.5%</strong>, capturing aspect ratio and extent. Together, 2 components retain <strong>96.8%</strong> of the variance.</p>
            <div class="img-container">
                <img src="{b64['pca']}" alt="PCA Scree and Biplot">
            </div>
        </div>

        <div class="section-card">
            <div class="section-header">
                <h2>t-SNE 2D Manifold Projection</h2>
            </div>
            <p class="section-desc">Non-linear projection demonstrates clear cluster separation with a narrow transition boundary where intermediate grain sizes overlap.</p>
            <div class="img-container">
                <img src="{b64['tsne']}" alt="t-SNE Projection">
            </div>
        </div>
    </div>

    <!-- Tab 6: Feature Engineering -->
    <div id="tab-engineering" class="tab-pane">
        <div class="section-card">
            <div class="section-header">
                <h2>Engineered Geometric Features</h2>
            </div>
            <p class="section-desc">We constructed 5 computer vision indices to better capture the shape, elongation, and circularity characteristics of the grains.</p>
            <div class="img-container">
                <img src="{b64['engineered']}" alt="Engineered Morphological Features">
            </div>
            
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Engineered Feature</th>
                            <th>Formula</th>
                            <th>Cammeo Mean</th>
                            <th>Osmancik Mean</th>
                            <th>Insight</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>Aspect_Ratio</strong></td>
                            <td><code>Major_Axis / Minor_Axis</code></td>
                            <td>2.316</td>
                            <td>2.087</td>
                            <td>Cammeo grains are ~11% more slender/elongated.</td>
                        </tr>
                        <tr>
                            <td><strong>Compactness</strong></td>
                            <td><code>4π × Area / Perimeter²</code></td>
                            <td>0.748</td>
                            <td>0.786</td>
                            <td>Osmancik grains are closer to circular/compact profiles.</td>
                        </tr>
                        <tr>
                            <td><strong>Solidity</strong></td>
                            <td><code>Area / Convex_Area</code></td>
                            <td>0.977</td>
                            <td>0.979</td>
                            <td>Both varieties have ultra-smooth outer silhouettes (>97%).</td>
                        </tr>
                        <tr>
                            <td><strong>Equivalent_Diameter</strong></td>
                            <td><code>√(4 × Area / π)</code></td>
                            <td>134.1 px</td>
                            <td>121.2 px</td>
                            <td>Effective optical diameter confirms 13 px differential.</td>
                        </tr>
                        <tr>
                            <td><strong>Roundness</strong></td>
                            <td><code>4 × Area / (π × Major_Axis²)</code></td>
                            <td>0.428</td>
                            <td>0.474</td>
                            <td>Osmancik kernels fill more of their major bounding circle.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Tab 7: ML Benchmark -->
    <div id="tab-ml" class="tab-pane">
        <div class="section-card">
            <div class="section-header">
                <h2>Mutual Information & Tree Feature Importance</h2>
            </div>
            <p class="section-desc">Both information-theoretic Mutual Information and Random Forest Gini impurity confirm <code>Major_Axis_Length</code> and <code>Perimeter</code> as the paramount features.</p>
            <div class="img-container">
                <img src="{b64['importance']}" alt="Feature Importance Ranking">
            </div>
        </div>

        <div class="section-card">
            <div class="section-header">
                <h2>5-Fold Stratified Cross-Validation Benchmark</h2>
            </div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Classifier</th>
                            <th>Mean Accuracy</th>
                            <th>Mean F1-Score</th>
                            <th>Mean ROC-AUC</th>
                            <th>Key Observation</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>Logistic Regression</strong></td>
                            <td><strong style="color: #4ade80;">92.81% (±0.85%)</strong></td>
                            <td>91.58% (±1.00%)</td>
                            <td>0.9790 (±0.0021)</td>
                            <td>Near-linear separability; exceptional performance with minimal compute.</td>
                        </tr>
                        <tr>
                            <td><strong>Random Forest (100 Trees)</strong></td>
                            <td>92.02% (±1.11%)</td>
                            <td>90.63% (±1.28%)</td>
                            <td>0.9724 (±0.0036)</td>
                            <td>Robust non-linear baseline confirming clean decision boundaries.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="callout">
                <strong>Deployment Recommendation:</strong> A calibrated Logistic Regression or Support Vector Classifier (SVC) with linear or RBF kernel is optimal for embedded edge devices (e.g. real-time optical sorters) due to sub-millisecond inference time.
            </div>
        </div>
    </div>

</div>

<script>
    function switchTab(evt, tabId) {{
        const panes = document.querySelectorAll('.tab-pane');
        panes.forEach(p => p.classList.remove('active'));

        const btns = document.querySelectorAll('.tab-btn');
        btns.forEach(b => b.classList.remove('active'));

        document.getElementById(tabId).classList.add('active');
        evt.currentTarget.classList.add('active');
    }}
</script>

</body>
</html>
"""

with open('eda_report.html', 'w', encoding='utf-8') as f:
    f.write(html_content)

print("Created self-contained HTML Dashboard 'eda_report.html'!")
