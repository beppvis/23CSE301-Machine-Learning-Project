# 🌾 Exploratory Data Analysis (EDA) Report
## Rice Variety Classification: *Cammeo* vs. *Osmancik*

**Dataset Reference:** Çınar, İ. & Köklü, M. (2019). *Classification of Rice Varieties Using Artificial Intelligence Methods.* International Journal of Intelligent Systems and Applications in Engineering, 7(3), 188–194.  
**Analysis Date:** September 2026  
**Artifacts Produced:**
- Executed Jupyter Notebook: [`rice_dataset_eda.ipynb`](file:///c:/Users/somul/OneDrive/Desktop/jj/rice_dataset_eda.ipynb)
- Interactive HTML Dashboard: [`eda_report.html`](file:///c:/Users/somul/OneDrive/Desktop/jj/eda_report.html)
- Cleaned CSV Export: [`rice_cleaned.csv`](file:///c:/Users/somul/OneDrive/Desktop/jj/rice_cleaned.csv)
- Python Automation Script: [`run_eda.py`](file:///c:/Users/somul/OneDrive/Desktop/jj/run_eda.py)
- High-Resolution Figures: [`eda_plots/`](file:///c:/Users/somul/OneDrive/Desktop/jj/eda_plots)

---

## 1. Executive Summary

This exploratory data analysis investigates the morphological, geometric, and shape features of **3,810** rice grain specimens belonging to two major commercial cultivars:
1. **Cammeo** ($n = 1,630$, **42.8%**): A long-grain rice cultivar.
2. **Osmancik** ($n = 2,180$, **57.2%**): A widely grown medium-grain rice cultivar.

### Key Discoveries:
1. **Data Hygiene**: The dataset has **zero missing values**, **zero duplicates**, and a minimal outlier prevalence (<1.8% across all attributes).
2. **Dominant Morphological Signal**: Grain length and circumference are the primary distinguishing features:
   - **`Major_Axis_Length`**: Welch's $t = 91.87$, $p < 10^{-300}$, Cohen's $d = 2.98$ (**Massive separation**).
   - **`Perimeter`**: Welch's $t = 85.06$, $p < 10^{-300}$, Cohen's $d = 2.76$.
   - **`Area`**: Welch's $t = 69.61$, $p < 10^{-300}$, Cohen's $d = 2.27$.
3. **Severe Multicollinearity**: `Area` and `Convex_Area` have a near-perfect linear correlation ($r = 0.999$, $\text{VIF} > 1,000$), because rice grain silhouettes are almost purely convex without significant concavities or indentations.
4. **Separability & Baseline Machine Learning**:
   - 2D Principal Component Analysis (PCA) retains **96.8%** of total dataset variance in just 2 components.
   - A standard linear model (Logistic Regression with 5-fold Stratified Cross-Validation) achieves **92.81% accuracy** ($\pm 0.85\%$) and **0.9790 ROC-AUC**, demonstrating strong linear separability in standardized feature space.

---

## 2. Dataset Architecture & Attributes

The dataset originates from computer vision segmentation of individual grain kernels.

| Attribute | Type | Units | Description |
| :--- | :--- | :--- | :--- |
| **`Area`** | Integer | $\text{px}^2$ | Number of pixels inside the grain perimeter. |
| **`Perimeter`** | Float | $\text{px}$ | Distance around the outer boundary of the grain. |
| **`Major_Axis_Length`** | Float | $\text{px}$ | Longest line connecting two opposing boundary points through the centroid. |
| **`Minor_Axis_Length`** | Float | $\text{px}$ | Longest perpendicular line across the grain. |
| **`Eccentricity`** | Float | Ratio $[0, 1)$ | Eccentricity of the ellipse with identical second moments as the grain region. |
| **`Convex_Area`** | Integer | $\text{px}^2$ | Number of pixels within the convex hull enclosing the grain. |
| **`Extent`** | Float | Ratio $(0, 1]$ | Ratio of grain area to the area of the grain's minimum bounding box. |
| **`Class`** | String | — | Rice variety (`Cammeo` or `Osmancik`). |

---

## 3. Univariate Statistical Distribution

### Continuous Feature Summary

| Feature | Mean | Std Dev | Median | IQR | Min | Max | Skewness | Kurtosis |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **`Area`** | 12,667.7 | 1,732.4 | 12,421.5 | 2,579.5 | 7,551.0 | 18,913.0 | 0.450 | -0.197 |
| **`Perimeter`** | 454.24 | 35.60 | 448.85 | 57.54 | 359.10 | 548.45 | 0.344 | -0.638 |
| **`Major_Axis_Length`** | 188.78 | 17.45 | 185.81 | 29.20 | 145.26 | 239.01 | 0.457 | -0.730 |
| **`Minor_Axis_Length`** | 86.31 | 5.73 | 86.43 | 7.41 | 59.53 | 107.54 | -0.106 | 0.887 |
| **`Eccentricity`** | 0.8869 | 0.0208 | 0.8891 | 0.0302 | 0.7772 | 0.9480 | -0.835 | 1.157 |
| **`Convex_Area`** | 12,952.5 | 1,777.0 | 12,706.5 | 2,657.8 | 7,723.0 | 19,099.0 | 0.441 | -0.218 |
| **`Extent`** | 0.6619 | 0.0772 | 0.6454 | 0.1277 | 0.4977 | 0.8611 | 0.472 | -0.906 |

### Normality Assessments:
- The Shapiro-Wilk and D'Agostino-Pearson tests reject univariate normality for all features ($p < 0.001$).
- The bimodality observed in `Major_Axis_Length` and `Perimeter` stems directly from the mixture of two distinct cultivars. Within each variety subclass, distributions approach near-Gaussian behavior.

---

## 4. Morphological Class Differentiation & Hypothesis Testing

To measure the biological divergence between the two cultivars, parametric (Welch's $t$-test) and non-parametric (Mann-Whitney $U$) tests were conducted:

| Feature | Cammeo Mean | Osmancik Mean | Mean Difference | Welch $t$-stat | $p$-value | Cohen's $d$ | Effect Magnitude |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| **`Major_Axis_Length`** | **205.48 px** | **176.29 px** | **+29.19 px** | 91.87 | $< 10^{-300}$ | **+2.98** | **Huge Separation** |
| **`Perimeter`** | **487.44 px** | **429.42 px** | **+58.02 px** | 85.06 | $< 10^{-300}$ | **+2.76** | **Huge Separation** |
| **`Convex_Area`** | **14,494.4 px²** | **11,799.6 px²** | **+2,694.8 px²** | 70.47 | $< 10^{-300}$ | **+2.29** | **Huge Separation** |
| **`Area`** | **14,162.9 px²** | **11,549.8 px²** | **+2,613.1 px²** | 69.61 | $< 10^{-300}$ | **+2.27** | **Huge Separation** |
| **`Eccentricity`** | **0.901** | **0.876** | **+0.025** | 45.83 | $< 10^{-300}$ | **+1.47** | **Very Large** |
| **`Minor_Axis_Length`** | **88.77 px** | **84.48 px** | **+4.29 px** | 25.13 | $4.09 \times 10^{-123}$ | **+0.81** | **Large** |
| **`Extent`** | **0.651** | **0.670** | **-0.018** | -7.18 | $8.44 \times 10^{-13}$ | **-0.24** | **Small** |

### Biological Interpretation:
1. **Grain Elongation**: Cammeo grains are ~16.6% longer along their major axis than Osmancik, while being only ~5.1% wider along their minor axis. This explains why Cammeo is classified as a long-grain rice and Osmancik as medium-grain.
2. **Boundary Smoothness**: The difference in `Area` vs `Convex_Area` is minimal across both cultivars, confirming intact, unbroken kernels in the sample.

---

## 5. Domain Feature Engineering

We evaluated 5 derived morphological parameters:

$$\text{Aspect Ratio} = \frac{\text{Major\_Axis\_Length}}{\text{Minor\_Axis\_Length}}$$

$$\text{Compactness} = \frac{4\pi \times \text{Area}}{\text{Perimeter}^2}$$

$$\text{Solidity} = \frac{\text{Area}}{\text{Convex\_Area}}$$

$$\text{Equivalent Diameter} = \sqrt{\frac{4 \times \text{Area}}{\pi}}$$

$$\text{Roundness} = \frac{4 \times \text{Area}}{\pi \times \text{Major\_Axis\_Length}^2}$$

### Engineered Feature Statistics:
| Feature | Cammeo Mean | Osmancik Mean | Insight |
| :--- | :---: | :---: | :--- |
| **`Aspect_Ratio`** | **2.316** | **2.087** | Cammeo kernels are ~11.0% more slender and elongated. |
| **`Compactness`** | **0.748** | **0.786** | Osmancik kernels have higher circularity/compactness. |
| **`Solidity`** | **0.977** | **0.979** | High perimeter smoothness across both varieties (>97%). |
| **`Equivalent_Diameter`** | **134.1 px** | **121.2 px** | Cammeo has an effective optical diameter 12.9 px larger. |
| **`Roundness`** | **0.428** | **0.474** | Osmancik fills a larger fraction of its circumscribing circle. |

---

## 6. Multivariate Correlation & Multicollinearity Analysis

### Pearson Correlation Matrix Highlights:
- $\text{Corr}(\text{Area}, \text{Convex\_Area}) = \mathbf{0.999}$ (Extreme collinearity).
- $\text{Corr}(\text{Area}, \text{Perimeter}) = \mathbf{0.967}$.
- $\text{Corr}(\text{Area}, \text{Major\_Axis\_Length}) = \mathbf{0.915}$.
- $\text{Corr}(\text{Minor\_Axis\_Length}, \text{Eccentricity}) = \mathbf{-0.591}$.
- $\text{Corr}(\text{Major\_Axis\_Length}, \text{Extent}) = \mathbf{-0.538}$.

### Variance Inflation Factor (VIF):
| Feature | VIF Value | Multicollinearity Assessment |
| :--- | :---: | :--- |
| **`Area`** | **1,170.53** | Extreme multicollinearity with `Convex_Area`. |
| **`Convex_Area`** | **1,047.28** | Redundant when `Area` is present. |
| **`Major_Axis_Length`** | **369.95** | High, but retains crucial morphological signal. |
| **`Perimeter`** | **233.03** | High collinearity with size features. |
| **`Minor_Axis_Length`** | **179.74** | Captures transverse grain width. |
| **`Eccentricity`** | **50.72** | Captures non-linear aspect curvature. |
| **`Extent`** | **1.14** | Completely orthogonal to size features. |

> [!TIP]
> When fitting generalized linear models (e.g. unregularized logistic regression), drop `Convex_Area` to eliminate coefficient inflation and variance explosion. Regularized models (L1/L2) and tree ensembles handle this naturally.

---

## 7. Dimensionality Reduction (PCA & t-SNE)

### Principal Component Analysis (PCA):
- **PC1 (74.3% variance)**: Heavily loaded by scale metrics (`Area`, `Convex_Area`, `Perimeter`, `Major_Axis_Length`).
- **PC2 (22.5% variance)**: Heavily loaded by shape metrics (`Extent`, `Minor_Axis_Length`, `Eccentricity`).
- **Cumulative Variance (PC1 + PC2)**: **96.8%** of total dataset variance is captured in 2 dimensions.

### t-SNE Manifold:
- Confirms two well-formed clusters with a narrow boundary region. The overlapping specimens correspond to undersized Cammeo grains and oversized Osmancik grains.

---

## 8. Outlier Profiling

Using Tukey's fence ($1.5 \times \text{IQR}$) and standard score thresholds ($|Z| > 3$):
- **`Perimeter`**: 0 IQR outliers, 0 Z-score outliers.
- **`Major_Axis_Length`**: 0 IQR outliers, 0 Z-score outliers.
- **`Area`**: 4 IQR outliers (0.10%), 3 Z-score outliers.
- **`Convex_Area`**: 3 IQR outliers (0.08%), 3 Z-score outliers.
- **`Minor_Axis_Length`**: 65 IQR outliers (1.71%), 19 Z-score outliers.
- **`Eccentricity`**: 21 IQR outliers (0.55%), 15 Z-score outliers.

**Conclusion:** Outliers represent natural biological variance rather than imaging artifacts. No data exclusion is necessary.

---

## 9. Baseline Machine Learning Classification

Evaluation using **5-Fold Stratified Cross-Validation**:

| Algorithm | Mean Accuracy | Mean F1-Score | Mean ROC-AUC |
| :--- | :---: | :---: | :---: |
| **Logistic Regression** | **92.81% (±0.85%)** | **91.58% (±1.00%)** | **0.9790 (±0.0021)** |
| **Random Forest (100 Trees)** | **92.02% (±1.11%)** | **90.63% (±1.28%)** | **0.9724 (±0.0036)** |

### Feature Importance (Mutual Information & Random Forest Gini):
1. **`Major_Axis_Length`**: MI = 0.395 | RF Gini = 0.342
2. **`Perimeter`**: MI = 0.370 | RF Gini = 0.285
3. **`Area`**: MI = 0.284 | RF Gini = 0.168
4. **`Convex_Area`**: MI = 0.280 | RF Gini = 0.088
5. **`Eccentricity`**: MI = 0.155 | RF Gini = 0.052
6. **`Minor_Axis_Length`**: MI = 0.068 | RF Gini = 0.043
7. **`Extent`**: MI = 0.012 | RF Gini = 0.022

---

## 10. Recommendations for Downstream Modeling

1. **Model Selection**: Because the boundary is largely linear in standardized space, **Logistic Regression** or **Linear SVM** provides competitive accuracy (~93%) with minimal computational overhead, ideal for embedded optical sorting hardware.
2. **Feature Pruning**: `Convex_Area` should be removed in linear pipelines to resolve multicollinearity ($\text{VIF} > 1,000$) without sacrificing predictive power.
3. **Engineered Features**: Including `Aspect_Ratio` or `Compactness` allows non-scale-invariant models to remain accurate even if imaging camera distance varies slightly.
